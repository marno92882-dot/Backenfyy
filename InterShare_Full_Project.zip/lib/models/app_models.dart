import 'dart:math' as math;

enum ServiceStatus { stopped, starting, connected, reconnecting, error }

enum ProxyMode { http, socks5, both }

enum PerformanceProfile { balanced, lowLatency, performance }

enum DnsMode { system, cloudflare, google, custom }

class AppSettings {
  final bool autoReconnect;
  final bool autoStart;
  final bool keepAlive;
  final bool notifications;
  final bool darkMode;
  final ProxyMode proxyMode;
  final int httpPort;
  final int socksPort;
  final DnsMode dnsMode;
  final String customDns;
  final int mtu;
  final int connectionTimeoutMs;
  final int reconnectDelayMs;
  final int bufferSize;
  final bool connectionReuse;
  final bool lowLatencyMode;
  final PerformanceProfile profile;
  final bool enableLogs;
  final bool ipv4;
  final bool ipv6;
  final bool bootStart;
  final List<String> bypassList;

  const AppSettings({
    this.autoReconnect = true,
    this.autoStart = false,
    this.keepAlive = true,
    this.notifications = true,
    this.darkMode = true,
    this.proxyMode = ProxyMode.both,
    this.httpPort = 8080,
    this.socksPort = 1080,
    this.dnsMode = DnsMode.system,
    this.customDns = '',
    this.mtu = 1500,
    this.connectionTimeoutMs = 8000,
    this.reconnectDelayMs = 1500,
    this.bufferSize = 16 * 1024,
    this.connectionReuse = true,
    this.lowLatencyMode = false,
    this.profile = PerformanceProfile.balanced,
    this.enableLogs = true,
    this.ipv4 = true,
    this.ipv6 = true,
    this.bootStart = false,
    this.bypassList = const [],
  });

  AppSettings copyWith({
    bool? autoReconnect,
    bool? autoStart,
    bool? keepAlive,
    bool? notifications,
    bool? darkMode,
    ProxyMode? proxyMode,
    int? httpPort,
    int? socksPort,
    DnsMode? dnsMode,
    String? customDns,
    int? mtu,
    int? connectionTimeoutMs,
    int? reconnectDelayMs,
    int? bufferSize,
    bool? connectionReuse,
    bool? lowLatencyMode,
    PerformanceProfile? profile,
    bool? enableLogs,
    bool? ipv4,
    bool? ipv6,
    bool? bootStart,
    List<String>? bypassList,
  }) {
    return AppSettings(
      autoReconnect: autoReconnect ?? this.autoReconnect,
      autoStart: autoStart ?? this.autoStart,
      keepAlive: keepAlive ?? this.keepAlive,
      notifications: notifications ?? this.notifications,
      darkMode: darkMode ?? this.darkMode,
      proxyMode: proxyMode ?? this.proxyMode,
      httpPort: httpPort ?? this.httpPort,
      socksPort: socksPort ?? this.socksPort,
      dnsMode: dnsMode ?? this.dnsMode,
      customDns: customDns ?? this.customDns,
      mtu: mtu ?? this.mtu,
      connectionTimeoutMs: connectionTimeoutMs ?? this.connectionTimeoutMs,
      reconnectDelayMs: reconnectDelayMs ?? this.reconnectDelayMs,
      bufferSize: bufferSize ?? this.bufferSize,
      connectionReuse: connectionReuse ?? this.connectionReuse,
      lowLatencyMode: lowLatencyMode ?? this.lowLatencyMode,
      profile: profile ?? this.profile,
      enableLogs: enableLogs ?? this.enableLogs,
      ipv4: ipv4 ?? this.ipv4,
      ipv6: ipv6 ?? this.ipv6,
      bootStart: bootStart ?? this.bootStart,
      bypassList: bypassList ?? this.bypassList,
    );
  }
}

class NetworkStats {
  final ServiceStatus status;
  final double uploadBytesPerSec;
  final double downloadBytesPerSec;
  final int totalUploadBytes;
  final int totalDownloadBytes;
  final int clientCount;
  final int uptimeSeconds;
  final int latencyMs;
  final String localIp;
  final String networkType;
  final bool vpnPrepared;
  final String dnsLabel;
  final int httpPort;
  final int socksPort;
  final String lastError;

  const NetworkStats({
    this.status = ServiceStatus.stopped,
    this.uploadBytesPerSec = 0,
    this.downloadBytesPerSec = 0,
    this.totalUploadBytes = 0,
    this.totalDownloadBytes = 0,
    this.clientCount = 0,
    this.uptimeSeconds = 0,
    this.latencyMs = 0,
    this.localIp = '—',
    this.networkType = 'Offline',
    this.vpnPrepared = false,
    this.dnsLabel = 'System Default',
    this.httpPort = 8080,
    this.socksPort = 1080,
    this.lastError = '',
  });

  NetworkStats copyWith({
    ServiceStatus? status,
    double? uploadBytesPerSec,
    double? downloadBytesPerSec,
    int? totalUploadBytes,
    int? totalDownloadBytes,
    int? clientCount,
    int? uptimeSeconds,
    int? latencyMs,
    String? localIp,
    String? networkType,
    bool? vpnPrepared,
    String? dnsLabel,
    int? httpPort,
    int? socksPort,
    String? lastError,
  }) {
    return NetworkStats(
      status: status ?? this.status,
      uploadBytesPerSec: uploadBytesPerSec ?? this.uploadBytesPerSec,
      downloadBytesPerSec: downloadBytesPerSec ?? this.downloadBytesPerSec,
      totalUploadBytes: totalUploadBytes ?? this.totalUploadBytes,
      totalDownloadBytes: totalDownloadBytes ?? this.totalDownloadBytes,
      clientCount: clientCount ?? this.clientCount,
      uptimeSeconds: uptimeSeconds ?? this.uptimeSeconds,
      latencyMs: latencyMs ?? this.latencyMs,
      localIp: localIp ?? this.localIp,
      networkType: networkType ?? this.networkType,
      vpnPrepared: vpnPrepared ?? this.vpnPrepared,
      dnsLabel: dnsLabel ?? this.dnsLabel,
      httpPort: httpPort ?? this.httpPort,
      socksPort: socksPort ?? this.socksPort,
      lastError: lastError ?? this.lastError,
    );
  }

  double get maxSpeed => math.max(uploadBytesPerSec, downloadBytesPerSec);
}

class LogEntry {
  final DateTime time;
  final String level;
  final String message;

  LogEntry(this.level, this.message) : time = DateTime.now();
}
