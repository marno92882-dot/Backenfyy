import 'package:flutter/material.dart';

import 'models/app_models.dart';
import 'screens/dashboard_screen.dart';
import 'screens/welcome_dialog.dart';
import 'services/app_controller.dart';
import 'services/preferences_service.dart';
import 'theme/app_theme.dart';
import 'widgets/background_video.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final preferences = await PreferencesService.create();
  final controller = AppController(preferences: preferences);
  await controller.initialize();
  runApp(InterShareApp(controller: controller));
}

class InterShareApp extends StatefulWidget {
  const InterShareApp({super.key, required this.controller});
  final AppController controller;

  @override
  State<InterShareApp> createState() => _InterShareAppState();
}

class _InterShareAppState extends State<InterShareApp> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final prefs = widget.controller.preferences;
      // The first-run flag is persisted through the same lightweight preference store.
      final raw = await prefs.getBool('welcomeShown');
      if (raw != true && mounted) {
        await showWelcomeDialog(context);
        await prefs.setBool('welcomeShown', true);
      }
      if (mounted && widget.controller.settings.autoStart) {
        await widget.controller.start();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'InterShare',
      theme: AppTheme.dark(),
      home: BackgroundVideo(child: DashboardScreen(controller: widget.controller)),
    );
  }
}
