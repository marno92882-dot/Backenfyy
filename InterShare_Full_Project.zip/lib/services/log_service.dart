import '../models/app_models.dart';
import '../native/native_bridge.dart';

class LogService {
  LogService._();
  static final LogService instance = LogService._();

  final List<LogEntry> _entries = <LogEntry>[];
  bool enabled = true;

  List<LogEntry> get entries => List.unmodifiable(_entries);

  void add(String level, String message) {
    if (!enabled) return;
    _entries.add(LogEntry(level, message));
    if (_entries.length > 250) {
      _entries.removeRange(0, _entries.length - 250);
    }
  }

  Future<void> clear() async {
    _entries.clear();
    await NativeBridge.instance.clearLogs();
  }
}
