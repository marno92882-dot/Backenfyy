import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_models.dart';

class PreferencesService {
  PreferencesService(this._prefs);

  final SharedPreferencesAsync _prefs;

  static Future<PreferencesService> create() async {
    return PreferencesService(SharedPreferencesAsync());
  }

  Future<bool> getBool(String key) async => await _prefs.getBool(key) ?? false;

  Future<void> setBool(String key, bool value) async => _prefs.setBool(key, value);

  Future<AppSettings> load() async {
    final proxyIndex = await _prefs.getInt('proxyMode') ?? ProxyMode.both.index;
    final dnsIndex = await _prefs.getInt('dnsMode') ?? DnsMode.system.index;
    final profileIndex = await _prefs.getInt('profile') ?? PerformanceProfile.balanced.index;
    final safeProxyIndex = proxyIndex.clamp(0, ProxyMode.values.length - 1).toInt();
    final safeDnsIndex = dnsIndex.clamp(0, DnsMode.values.length - 1).toInt();
    final safeProfileIndex = profileIndex.clamp(0, PerformanceProfile.values.length - 1).toInt();
    return AppSettings(
      autoReconnect: await _prefs.getBool('autoReconnect') ?? true,
      autoStart: await _prefs.getBool('autoStart') ?? false,
      keepAlive: await _prefs.getBool('keepAlive') ?? true,
      notifications: await _prefs.getBool('notifications') ?? true,
      darkMode: await _prefs.getBool('darkMode') ?? true,
      proxyMode: ProxyMode.values[safeProxyIndex],
      httpPort: await _prefs.getInt('httpPort') ?? 8080,
      socksPort: await _prefs.getInt('socksPort') ?? 1080,
      dnsMode: DnsMode.values[safeDnsIndex],
      customDns: await _prefs.getString('customDns') ?? '',
      mtu: await _prefs.getInt('mtu') ?? 1500,
      connectionTimeoutMs: await _prefs.getInt('connectionTimeoutMs') ?? 8000,
      reconnectDelayMs: await _prefs.getInt('reconnectDelayMs') ?? 1500,
      bufferSize: await _prefs.getInt('bufferSize') ?? (16 * 1024),
      connectionReuse: await _prefs.getBool('connectionReuse') ?? true,
      lowLatencyMode: await _prefs.getBool('lowLatencyMode') ?? false,
      profile: PerformanceProfile.values[safeProfileIndex],
      enableLogs: await _prefs.getBool('enableLogs') ?? true,
      ipv4: await _prefs.getBool('ipv4') ?? true,
      ipv6: await _prefs.getBool('ipv6') ?? true,
      bootStart: await _prefs.getBool('bootStart') ?? false,
      bypassList: await _prefs.getStringList('bypassList') ?? const [],
    );
  }

  Future<void> save(AppSettings s) async {
    await _prefs.setBool('autoReconnect', s.autoReconnect);
    await _prefs.setBool('autoStart', s.autoStart);
    await _prefs.setBool('keepAlive', s.keepAlive);
    await _prefs.setBool('notifications', s.notifications);
    await _prefs.setBool('darkMode', s.darkMode);
    await _prefs.setInt('proxyMode', s.proxyMode.index);
    await _prefs.setInt('httpPort', s.httpPort);
    await _prefs.setInt('socksPort', s.socksPort);
    await _prefs.setInt('dnsMode', s.dnsMode.index);
    await _prefs.setString('customDns', s.customDns);
    await _prefs.setInt('mtu', s.mtu);
    await _prefs.setInt('connectionTimeoutMs', s.connectionTimeoutMs);
    await _prefs.setInt('reconnectDelayMs', s.reconnectDelayMs);
    await _prefs.setInt('bufferSize', s.bufferSize);
    await _prefs.setBool('connectionReuse', s.connectionReuse);
    await _prefs.setBool('lowLatencyMode', s.lowLatencyMode);
    await _prefs.setInt('profile', s.profile.index);
    await _prefs.setBool('enableLogs', s.enableLogs);
    await _prefs.setBool('ipv4', s.ipv4);
    await _prefs.setBool('ipv6', s.ipv6);
    await _prefs.setBool('bootStart', s.bootStart);
    await _prefs.setStringList('bypassList', s.bypassList);
  }
}
