import 'dart:async';

import '../models/app_models.dart';
import '../native/native_bridge.dart';
import 'log_service.dart';
import 'preferences_service.dart';

class AppController {
  AppController({required this.preferences});

  final PreferencesService preferences;
  final LogService logs = LogService.instance;
  final NativeBridge native = NativeBridge.instance;

  AppSettings settings = const AppSettings();
  NetworkStats stats = const NetworkStats();
  StreamSubscription<NetworkStats>? _sub;

  final StreamController<NetworkStats> _statsController = StreamController.broadcast();
  final StreamController<AppSettings> _settingsController = StreamController.broadcast();

  Stream<NetworkStats> get statsStream => _statsController.stream;
  Stream<AppSettings> get settingsStream => _settingsController.stream;

  Future<void> initialize() async {
    settings = await preferences.load();
    logs.enabled = settings.enableLogs;
    stats = await native.getStats();
    _sub ??= native.events.listen((value) {
      stats = value;
      _statsController.add(value);
    });
  }

  Future<void> saveSettings(AppSettings value) async {
    settings = value;
    logs.enabled = value.enableLogs;
    await preferences.save(value);
    _settingsController.add(value);
    await native.startServiceIfRunning(value);
  }

  Future<void> start() async {
    await native.startService(settings);
    logs.add('INFO', 'Sharing start requested');
  }

  Future<void> stop() async {
    await native.stopService();
    logs.add('INFO', 'Sharing stopped');
  }

  Future<void> dispose() async {
    await _sub?.cancel();
    await _statsController.close();
    await _settingsController.close();
  }
}

extension _NativeRunningUpdate on NativeBridge {
  Future<void> startServiceIfRunning(AppSettings settings) async {
    final stats = await getStats();
    if (stats.status == ServiceStatus.connected || stats.status == ServiceStatus.starting || stats.status == ServiceStatus.reconnecting) {
      await startService(settings);
    }
  }
}
