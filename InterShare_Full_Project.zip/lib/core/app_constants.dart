class AppConstants {
  static const appName = 'InterShare';
  static const packageName = 'com.intershare.marnommk';
  static const version = '1.0.0+1';
  static const defaultHttpPort = 8080;
  static const defaultSocksPort = 1080;
}
