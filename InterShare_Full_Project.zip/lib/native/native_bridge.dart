import 'dart:async';

import 'package:flutter/services.dart';

import '../models/app_models.dart';

class NativeBridge {
  NativeBridge._();
  static final NativeBridge instance = NativeBridge._();

  static const MethodChannel _methods = MethodChannel('com.intershare.marnommk/native');
  static const EventChannel _events = EventChannel('com.intershare.marnommk/events');

  Stream<NetworkStats> get events => _events.receiveBroadcastStream().map(NetworkStatsMapper.fromMap);

  Future<NetworkStats> getStats() async {
    final raw = await _methods.invokeMethod<dynamic>('getStats');
    return NetworkStatsMapper.fromMap(raw is Map ? Map<dynamic, dynamic>.from(raw) : const {});
  }

  Future<void> startService(AppSettings settings) async {
    await _methods.invokeMethod<void>('startService', settings.toMap());
  }

  Future<void> stopService() async {
    await _methods.invokeMethod<void>('stopService');
  }

  Future<bool> isVpnPrepared() async {
    return await _methods.invokeMethod<bool>('isVpnPrepared') ?? false;
  }

  Future<bool> prepareVpn() async {
    return await _methods.invokeMethod<bool>('prepareVpn') ?? false;
  }

  Future<void> clearLogs() async => _methods.invokeMethod<void>('clearLogs');

  Future<void> exportLogs() async => _methods.invokeMethod<void>('exportLogs');

  Future<List<Map<String, dynamic>>> getLogs() async {
    final raw = await _methods.invokeMethod<dynamic>('getLogs');
    if (raw is! List) return const [];
    return raw
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList(growable: false);
  }
}

extension _SettingsMap on AppSettings {
  Map<String, dynamic> toMap() => <String, dynamic>{
        'autoReconnect': autoReconnect,
        'autoStart': autoStart,
        'keepAlive': keepAlive,
        'notifications': notifications,
        'darkMode': darkMode,
        'proxyMode': proxyMode.name,
        'httpPort': httpPort,
        'socksPort': socksPort,
        'dnsMode': dnsMode.name,
        'customDns': customDns,
        'mtu': mtu,
        'connectionTimeoutMs': connectionTimeoutMs,
        'reconnectDelayMs': reconnectDelayMs,
        'bufferSize': bufferSize,
        'connectionReuse': connectionReuse,
        'lowLatencyMode': lowLatencyMode,
        'profile': profile.name,
        'enableLogs': enableLogs,
        'ipv4': ipv4,
        'ipv6': ipv6,
        'bootStart': bootStart,
        'bypassList': bypassList,
      };

  static AppSettings fromMap(Map<dynamic, dynamic> map) => AppSettings(
        autoReconnect: map['autoReconnect'] as bool? ?? true,
        autoStart: map['autoStart'] as bool? ?? false,
        keepAlive: map['keepAlive'] as bool? ?? true,
        notifications: map['notifications'] as bool? ?? true,
        darkMode: map['darkMode'] as bool? ?? true,
        proxyMode: _enumByName(ProxyMode.values, map['proxyMode'] as String?, ProxyMode.both),
        httpPort: (map['httpPort'] as num?)?.toInt() ?? 8080,
        socksPort: (map['socksPort'] as num?)?.toInt() ?? 1080,
        dnsMode: _enumByName(DnsMode.values, map['dnsMode'] as String?, DnsMode.system),
        customDns: map['customDns'] as String? ?? '',
        mtu: (map['mtu'] as num?)?.toInt() ?? 1500,
        connectionTimeoutMs: (map['connectionTimeoutMs'] as num?)?.toInt() ?? 8000,
        reconnectDelayMs: (map['reconnectDelayMs'] as num?)?.toInt() ?? 1500,
        bufferSize: (map['bufferSize'] as num?)?.toInt() ?? 16384,
        connectionReuse: map['connectionReuse'] as bool? ?? true,
        lowLatencyMode: map['lowLatencyMode'] as bool? ?? false,
        profile: _enumByName(PerformanceProfile.values, map['profile'] as String?, PerformanceProfile.balanced),
        enableLogs: map['enableLogs'] as bool? ?? true,
        ipv4: map['ipv4'] as bool? ?? true,
        ipv6: map['ipv6'] as bool? ?? true,
        bootStart: map['bootStart'] as bool? ?? false,
        bypassList: (map['bypassList'] as List?)?.whereType<String>().toList() ?? const [],
      );

  static T _enumByName<T extends Enum>(List<T> values, String? name, T fallback) {
    for (final value in values) {
      if (value.name == name) return value;
    }
    return fallback;
  }
}

class NetworkStatsMapper {
  static NetworkStats fromMap(Map<dynamic, dynamic> map) {
    return NetworkStats(
      status: _status(map['status'] as String?),
      uploadBytesPerSec: (map['uploadBytesPerSec'] as num?)?.toDouble() ?? 0,
      downloadBytesPerSec: (map['downloadBytesPerSec'] as num?)?.toDouble() ?? 0,
      totalUploadBytes: (map['totalUploadBytes'] as num?)?.toInt() ?? 0,
      totalDownloadBytes: (map['totalDownloadBytes'] as num?)?.toInt() ?? 0,
      clientCount: (map['clientCount'] as num?)?.toInt() ?? 0,
      uptimeSeconds: (map['uptimeSeconds'] as num?)?.toInt() ?? 0,
      latencyMs: (map['latencyMs'] as num?)?.toInt() ?? 0,
      localIp: map['localIp'] as String? ?? '—',
      networkType: map['networkType'] as String? ?? 'Offline',
      vpnPrepared: map['vpnPrepared'] as bool? ?? false,
      dnsLabel: map['dnsLabel'] as String? ?? 'System Default',
      httpPort: (map['httpPort'] as num?)?.toInt() ?? 8080,
      socksPort: (map['socksPort'] as num?)?.toInt() ?? 1080,
      lastError: map['lastError'] as String? ?? '',
    );
  }

  static ServiceStatus _status(String? raw) {
    return ServiceStatus.values.firstWhere((s) => s.name == raw, orElse: () => ServiceStatus.stopped);
  }
}
