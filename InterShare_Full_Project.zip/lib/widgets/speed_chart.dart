import 'dart:math' as math;

import 'package:flutter/material.dart';

class SpeedChart extends StatelessWidget {
  const SpeedChart({super.key, required this.download, required this.upload});

  final List<double> download;
  final List<double> upload;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 170,
      width: double.infinity,
      child: CustomPaint(
        painter: _SpeedPainter(download: download, upload: upload),
      ),
    );
  }
}

class _SpeedPainter extends CustomPainter {
  _SpeedPainter({required this.download, required this.upload});
  final List<double> download;
  final List<double> upload;

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = const Color(0xFF162235)
      ..strokeWidth = 1;
    for (var i = 1; i < 5; i++) {
      final y = size.height * i / 5;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final maxValue = math.max(1.0, [...download, ...upload].fold<double>(0, math.max));
    _drawSeries(canvas, size, download, maxValue, const Color(0xFF3DA7FF));
    _drawSeries(canvas, size, upload, maxValue, const Color(0xFF7B61FF));
  }

  void _drawSeries(Canvas canvas, Size size, List<double> data, double maxValue, Color color) {
    if (data.length < 2) return;
    final path = Path();
    final step = size.width / (data.length - 1);
    for (var i = 0; i < data.length; i++) {
      final x = step * i;
      final y = size.height - (data[i] / maxValue) * size.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    final fill = Path.from(path)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(
      fill,
      Paint()..color = color.withValues(alpha: 0.08),
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
  }

  @override
  bool shouldRepaint(covariant _SpeedPainter oldDelegate) => true;
}
