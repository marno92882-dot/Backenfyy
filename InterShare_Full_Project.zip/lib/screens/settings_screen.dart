import 'package:flutter/material.dart';

import '../models/app_models.dart';
import '../native/native_bridge.dart';
import '../services/app_controller.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late AppSettings settings;

  @override
  void initState() {
    super.initState();
    settings = widget.controller.settings;
  }

  Future<void> _save(AppSettings value) async {
    setState(() => settings = value);
    await widget.controller.saveSettings(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          _section('GENERAL', [
            _switchTile('Auto Reconnect', 'Retry broken upstream connections with bounded backoff.', settings.autoReconnect, (v) => _save(settings.copyWith(autoReconnect: v))),
            _switchTile('Auto Start', 'Start sharing when the app is started.', settings.autoStart, (v) => _save(settings.copyWith(autoStart: v))),
            _switchTile('Keep Service Alive', 'Keep the foreground service active while sharing.', settings.keepAlive, (v) => _save(settings.copyWith(keepAlive: v))),
            const SwitchListTile.adaptive(
              value: true,
              onChanged: null,
              title: Text('Notification (required)'),
              subtitle: Text('Modern Android requires a visible foreground-service notification while sharing.'),
            ),
          ]),
          _section('NETWORK', [
            _dropdownTile<ProxyMode>('Proxy Mode', settings.proxyMode, ProxyMode.values, (v) => _save(settings.copyWith(proxyMode: v)), (v) => v.name.toUpperCase()),
            _portTile('HTTP Port', settings.httpPort, (v) => _save(settings.copyWith(httpPort: v))),
            _portTile('SOCKS5 Port', settings.socksPort, (v) => _save(settings.copyWith(socksPort: v))),
            _dropdownTile<DnsMode>('DNS', settings.dnsMode, DnsMode.values, (v) => _save(settings.copyWith(dnsMode: v)), (v) => switch (v) {
                  DnsMode.system => 'System Default',
                  DnsMode.cloudflare => 'Cloudflare (1.1.1.1)',
                  DnsMode.google => 'Google (8.8.8.8)',
                  DnsMode.custom => 'Custom',
                }),
            if (settings.dnsMode == DnsMode.custom)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: TextFormField(
                  initialValue: settings.customDns,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Custom DNS IPv4'),
                  onFieldSubmitted: (v) => _save(settings.copyWith(customDns: v.trim())),
                ),
              ),
            _sliderTile('Connection Timeout', settings.connectionTimeoutMs.toDouble(), 2000, 20000, (v) => _save(settings.copyWith(connectionTimeoutMs: v.round()))),
            _sliderTile('Reconnect Delay', settings.reconnectDelayMs.toDouble(), 500, 10000, (v) => _save(settings.copyWith(reconnectDelayMs: v.round()))),
          ]),
          _section('PERFORMANCE', [
            _dropdownTile<PerformanceProfile>('Performance Profile', settings.profile, PerformanceProfile.values, (v) => _save(settings.copyWith(profile: v)), (v) => switch (v) {
                  PerformanceProfile.balanced => 'Balanced',
                  PerformanceProfile.lowLatency => 'Low Latency',
                  PerformanceProfile.performance => 'Performance',
                }),
            _sliderTile('Buffer Size', settings.bufferSize.toDouble(), 4096, 65536, (v) => _save(settings.copyWith(bufferSize: v.round()))),
            _switchTile('Connection Reuse', 'Reuse compatible upstream sockets where protocol semantics allow it.', settings.connectionReuse, (v) => _save(settings.copyWith(connectionReuse: v))),
            _switchTile('Low Latency Mode', 'Reduce batching where it improves interactive traffic.', settings.lowLatencyMode, (v) => _save(settings.copyWith(lowLatencyMode: v))),
          ]),
          _section('LOGGING', [
            _switchTile('Enable Logs', 'Keep concise local diagnostic logs.', settings.enableLogs, (v) => _save(settings.copyWith(enableLogs: v))),
            ListTile(
              leading: const Icon(Icons.delete_sweep_outlined),
              title: const Text('Clear Logs'),
              onTap: () async {
                await widget.controller.logs.clear();
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Logs cleared')));
              },
            ),
            ListTile(
              leading: const Icon(Icons.ios_share_outlined),
              title: const Text('Export Logs'),
              onTap: () => NativeBridge.instance.exportLogs(),
            ),
          ]),
          _section('ADVANCED', [
            _switchTile('IPv4', 'Enable IPv4 connections.', settings.ipv4, (v) => _save(settings.copyWith(ipv4: v))),
            _switchTile('IPv6', 'Allow IPv6 upstream when the target resolves to IPv6.', settings.ipv6, (v) => _save(settings.copyWith(ipv6: v))),
            ListTile(
              title: const Text('Bypass List'),
              subtitle: Text(settings.bypassList.isEmpty ? 'No domains bypassed.' : settings.bypassList.join(', ')),
              leading: const Icon(Icons.rule_folder_outlined),
              onTap: () => _showBypassEditor(),
            ),
            const ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('VPN routing'),
              subtitle: Text('Not enabled in Proxy Mode. Full-device traffic capture requires a complete user-space packet/TCP forwarding stack and is intentionally not faked.'),
            ),
          ]),
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              'Android 15+ may restrict long-running foreground-service types. InterShare uses the special-use foreground service type for its user-visible local proxy sharing service and stops cleanly when asked by the system.',
              style: TextStyle(color: Colors.white60, height: 1.45),
            ),
          ),
        ],
      ),
    );
  }

  Widget _section(String title, List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
          child: Text(title, style: const TextStyle(letterSpacing: 1.4, fontWeight: FontWeight.w800, color: Colors.white70)),
        ),
        Container(
          decoration: BoxDecoration(color: const Color(0xB80C1423), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF17243A))),
          child: Column(children: children),
        ),
      ]),
    );
  }

  Widget _switchTile(String title, String subtitle, bool value, ValueChanged<bool> onChanged) {
    return SwitchListTile.adaptive(title: Text(title), subtitle: Text(subtitle), value: value, onChanged: onChanged);
  }

  Widget _portTile(String title, int value, ValueChanged<int> onChanged) {
    return ListTile(
      title: Text(title),
      subtitle: const Text('Valid range: 1024–65535'),
      trailing: SizedBox(
        width: 90,
        child: TextFormField(
          initialValue: '$value',
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          onFieldSubmitted: (text) {
            final v = int.tryParse(text) ?? value;
            if (v >= 1024 && v <= 65535) onChanged(v);
          },
        ),
      ),
    );
  }

  Widget _dropdownTile<T>(String title, T value, List<T> values, ValueChanged<T> onChanged, String Function(T) label) {
    return ListTile(
      title: Text(title),
      trailing: DropdownButton<T>(
        value: value,
        underline: const SizedBox.shrink(),
        items: values.map((v) => DropdownMenuItem<T>(value: v, child: Text(label(v)))).toList(),
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
      ),
    );
  }

  Widget _sliderTile(String title, double value, double min, double max, ValueChanged<double> onChanged) {
    return ListTile(
      title: Text(title),
      subtitle: Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, onChanged: onChanged),
      trailing: Text(value.round().toString()),
    );
  }

  Future<void> _showBypassEditor() async {
    final controller = TextEditingController(text: settings.bypassList.join('\n'));
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Bypass List'),
        content: TextField(controller: controller, minLines: 6, maxLines: 12, decoration: const InputDecoration(hintText: 'one domain per line')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCEL')),
          FilledButton(
            onPressed: () {
              final list = controller.text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
              Navigator.pop(context);
              _save(settings.copyWith(bypassList: list));
            },
            child: const Text('SAVE'),
          ),
        ],
      ),
    );
    controller.dispose();
  }
}
