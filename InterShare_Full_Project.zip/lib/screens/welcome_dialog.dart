import 'package:flutter/material.dart';

Future<void> showWelcomeDialog(BuildContext context) async {
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (context) => AlertDialog(
      backgroundColor: const Color(0xFF0C1423),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: const Row(
        children: [
          Icon(Icons.hub_rounded),
          SizedBox(width: 10),
          Text('Welcome to InterShare'),
        ],
      ),
      content: const Text(
        'InterShare provides local HTTP and SOCKS5 proxy sharing from your Android device. It is designed for stable, low-overhead local sharing without root or private Android APIs.',
      ),
      actions: [
        FilledButton(onPressed: () => Navigator.pop(context), child: const Text('GET STARTED')),
      ],
    ),
  );
}
