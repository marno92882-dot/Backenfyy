import 'package:flutter/material.dart';

import '../services/app_controller.dart';
import '../native/native_bridge.dart';

class LogsScreen extends StatefulWidget {
  const LogsScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<LogsScreen> createState() => _LogsScreenState();
}

class _LogsScreenState extends State<LogsScreen> {
  Future<List<Map<String, dynamic>>> _load() => NativeBridge.instance.getLogs();

  @override
  Widget build(BuildContext context) {
    final items = widget.controller.logs.entries.reversed.toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Logs'),
        actions: [
          IconButton(onPressed: () async { await widget.controller.logs.clear(); setState(() {}); }, icon: const Icon(Icons.delete_outline)),
        ],
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _load(),
        builder: (context, snapshot) {
          final nativeItems = snapshot.data ?? const <Map<String, dynamic>>[];
          if (nativeItems.isEmpty && items.isEmpty) return const Center(child: Text('No local diagnostic logs.'));
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: nativeItems.isNotEmpty ? nativeItems.length : items.length,
            itemBuilder: (_, index) {
              if (nativeItems.isNotEmpty) {
                final item = nativeItems[index];
                final level = item['level']?.toString() ?? 'INFO';
                return ListTile(
                  dense: true,
                  leading: Icon(switch (level) { 'ERROR' => Icons.error_outline, 'WARNING' => Icons.warning_amber_rounded, _ => Icons.info_outline }),
                  title: Text(item['message']?.toString() ?? ''),
                  subtitle: Text('$level • ${item['time'] ?? ''}'),
                );
              }
              final item = items[index];
              return ListTile(
                dense: true,
                leading: const Icon(Icons.info_outline),
                title: Text(item.message),
                subtitle: Text('${item.level} • ${item.time.toLocal()}'),
              );
            },
          );
        },
      ),
    );
  }
}
