import 'dart:async';
import 'package:flutter/material.dart';

import '../models/app_models.dart';
import '../services/app_controller.dart';
import '../utils/formatters.dart';
import '../widgets/speed_chart.dart';
import '../widgets/stat_card.dart';
import 'logs_screen.dart';
import 'settings_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with SingleTickerProviderStateMixin {
  final List<double> _download = <double>[];
  final List<double> _upload = <double>[];
  StreamSubscription<NetworkStats>? _subscription;
  late final AnimationController _pulse;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
    _subscription = widget.controller.statsStream.listen((s) {
      if (!mounted) return;
      setState(() {
        _download.add(s.downloadBytesPerSec);
        _upload.add(s.uploadBytesPerSec);
        if (_download.length > 40) _download.removeAt(0);
        if (_upload.length > 40) _upload.removeAt(0);
      });
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _pulse.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    setState(() => _busy = true);
    try {
      if (_isRunning(widget.controller.stats.status)) {
        await widget.controller.stop();
      } else {
        await widget.controller.start();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Operation failed: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  bool _isRunning(ServiceStatus status) => status == ServiceStatus.starting || status == ServiceStatus.connected || status == ServiceStatus.reconnecting;

  @override
  Widget build(BuildContext context) {
    final s = widget.controller.stats;
    final running = _isRunning(s.status);
    final statusText = switch (s.status) {
      ServiceStatus.connected => 'CONNECTED',
      ServiceStatus.starting => 'STARTING',
      ServiceStatus.reconnecting => 'RECONNECTING',
      ServiceStatus.error => 'ERROR',
      ServiceStatus.stopped => 'DISCONNECTED',
    };
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [Icon(Icons.hub_rounded), SizedBox(width: 8), Text('InterShare', style: TextStyle(fontWeight: FontWeight.w800))]),
        actions: [
          IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LogsScreen(controller: widget.controller))), icon: const Icon(Icons.receipt_long_outlined)),
          IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen(controller: widget.controller))), icon: const Icon(Icons.tune_rounded)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 32),
        children: [
          _statusHeader(s, running, statusText),
          const SizedBox(height: 14),
          _heroButton(running),
          const SizedBox(height: 14),
          _speedPanel(s),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 2,
            childAspectRatio: 1.72,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              StatCard(label: 'Download', value: Formatters.speed(s.downloadBytesPerSec), icon: Icons.download_rounded),
              StatCard(label: 'Upload', value: Formatters.speed(s.uploadBytesPerSec), icon: Icons.upload_rounded),
              StatCard(label: 'Clients', value: '${s.clientCount}', icon: Icons.devices_other_rounded),
              StatCard(label: 'Latency', value: '${s.latencyMs} ms', icon: Icons.speed_rounded),
            ],
          ),
          const SizedBox(height: 14),
          _detailPanel(s),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: const Color(0xAA0C1423), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF17243A))),
            child: const Row(
              children: [Icon(Icons.battery_saver_outlined, color: Colors.amber), SizedBox(width: 12), Expanded(child: Text('Sharing can increase battery and radio usage. InterShare avoids busy polling and keeps stats sampling lightweight.'))],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statusHeader(NetworkStats s, bool running, String statusText) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xE61C3B66), Color(0xD90C1423)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFF24436F)),
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, child) => Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(shape: BoxShape.circle, color: (running ? const Color(0xFF2F7DFF) : Colors.white10).withValues(alpha: 0.14 + 0.08 * _pulse.value)),
              child: child,
            ),
            child: Icon(running ? Icons.wifi_tethering_rounded : Icons.wifi_off_rounded, color: running ? const Color(0xFF6FB6FF) : Colors.white54, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(statusText, style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)), const SizedBox(height: 4), Text('${s.networkType} • ${s.localIp}', style: const TextStyle(color: Colors.white70))])),
          if (s.lastError.isNotEmpty) const Icon(Icons.error_outline, color: Colors.orangeAccent),
        ],
      ),
    );
  }

  Widget _heroButton(bool running) {
    return SizedBox(
      height: 66,
      child: FilledButton(
        onPressed: _busy ? null : _toggle,
        style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
        child: _busy
            ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.5))
            : Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(running ? Icons.stop_circle_outlined : Icons.play_circle_outline_rounded, size: 28), const SizedBox(width: 10), Text(running ? 'STOP SHARING' : 'START SHARING', style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1))]),
      ),
    );
  }

  Widget _speedPanel(NetworkStats s) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      decoration: BoxDecoration(color: const Color(0xB80C1423), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFF17243A))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Text('LIVE TRAFFIC', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.3)), const Spacer(), Text('${Formatters.bytes(s.totalDownloadBytes + s.totalUploadBytes)} total', style: const TextStyle(color: Colors.white54))]),
        const SizedBox(height: 8),
        Row(children: [const Icon(Icons.arrow_downward_rounded, size: 16, color: Color(0xFF3DA7FF)), const SizedBox(width: 4), Text(Formatters.speed(s.downloadBytesPerSec)), const SizedBox(width: 16), const Icon(Icons.arrow_upward_rounded, size: 16, color: Color(0xFF7B61FF)), const SizedBox(width: 4), Text(Formatters.speed(s.uploadBytesPerSec))]),
        SpeedChart(download: _download, upload: _upload),
      ]),
    );
  }

  Widget _detailPanel(NetworkStats s) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xB80C1423), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFF17243A))),
      child: Column(children: [
        _detail('HTTP Proxy', ':${s.httpPort}'),
        _detail('SOCKS5 Proxy', ':${s.socksPort}'),
        _detail('DNS', s.dnsLabel),
        _detail('Uptime', Formatters.uptime(s.uptimeSeconds)),
        _detail('Total Upload', Formatters.bytes(s.totalUploadBytes)),
        _detail('Total Download', Formatters.bytes(s.totalDownloadBytes)),
        _detail('VPN Permission', s.vpnPrepared ? 'Prepared' : 'Not prepared'),
        if (s.lastError.isNotEmpty) _detail('Last Error', s.lastError),
      ]),
    );
  }

  Widget _detail(String key, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(children: [Text(key, style: const TextStyle(color: Colors.white60)), const Spacer(), Flexible(child: Text(value, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700)))]),
    );
  }
}
