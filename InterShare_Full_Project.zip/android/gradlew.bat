@echo off
setlocal enabledelayedexpansion
set GRADLE_VERSION=9.1.0
if defined GRADLE_USER_HOME (set CACHE_DIR=%GRADLE_USER_HOME%\wrapper\dists\intershare-gradle-%GRADLE_VERSION%) else (set CACHE_DIR=%USERPROFILE%\.gradle\wrapper\dists\intershare-gradle-%GRADLE_VERSION%)
set DIST_ZIP=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip
set DIST_DIR=%CACHE_DIR%\gradle-%GRADLE_VERSION%
if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  if not exist "%DIST_ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%DIST_ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%DIST_ZIP%' '%CACHE_DIR%'"
)
call "%DIST_DIR%\bin\gradle.bat" %*
endlocal
