package com.intershare.marnommk

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.SystemClock
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.SocketTimeoutException
import java.nio.charset.StandardCharsets
import java.util.Collections
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max

class ProxyEngine(private val context: Context, private val onState: (Map<String, Any?>) -> Unit) {
    private val lock = Any()
    private val running = AtomicBoolean(false)
    private val clients = ConcurrentHashMap.newKeySet<Socket>()
    private val executor = Executors.newCachedThreadPool { r -> Thread(r, "InterShare-net").apply { isDaemon = true } }
    private val sampler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "InterShare-stats").apply { isDaemon = true } }
    private val logger = NativeLogger(context)
    private val upBytes = AtomicLong(0)
    private val downBytes = AtomicLong(0)
    private var lastUp = 0L
    private var lastDown = 0L
    private var httpServer: ServerSocket? = null
    private var socksServer: ServerSocket? = null
    private var startElapsed = 0L
    private var config = SettingsStore.Config()
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var sampleTask: java.util.concurrent.ScheduledFuture<*>? = null
    private var reconnectAttempt = 0
    private var currentLatency = 0
    private var lastError = ""

    fun start() {
        synchronized(lock) {
            if (running.get()) return
            config = SettingsStore(context).load().sanitized()
            validateConfig(config)
            lastError = ""
            startElapsed = SystemClock.elapsedRealtime()
            reconnectAttempt = 0
            try {
                if (config.proxyMode == "http" || config.proxyMode == "both") {
                    httpServer = ServerSocket(config.httpPort, 64, InetAddress.getByName("0.0.0.0"))
                }
                if (config.proxyMode == "socks5" || config.proxyMode == "both") {
                    socksServer = ServerSocket(config.socksPort, 64, InetAddress.getByName("0.0.0.0"))
                }
                running.set(true)
                logger.log("INFO", "Proxy engine started on ${config.proxyMode}; HTTP=${config.httpPort}, SOCKS5=${config.socksPort}")
                registerNetworkCallback()
                httpServer?.let { server -> executor.execute { acceptLoop(server, ProxyKind.HTTP) } }
                socksServer?.let { server -> executor.execute { acceptLoop(server, ProxyKind.SOCKS5) } }
                sampleTask?.cancel(false)
                sampleTask = sampler.scheduleAtFixedRate({ sample() }, 500, 1000, TimeUnit.MILLISECONDS)
                emit("connected")
            } catch (t: Throwable) {
                closeServers()
                unregisterNetworkCallback()
                lastError = humanError(t)
                running.set(false)
                emit("error")
                throw t
            }
        }
    }

    fun stop() {
        synchronized(lock) {
            if (!running.getAndSet(false)) return
            unregisterNetworkCallback()
            sampleTask?.cancel(false)
            sampleTask = null
            closeServers()
            clients.toList().forEach { runCatching { it.close() } }
            clients.clear()
            logger.log("INFO", "Proxy engine stopped")
            emit("stopped")
        }
    }

    fun isRunning(): Boolean = running.get()

    fun reload() {
        if (!running.get()) return
        val wasRunning = running.get()
        stop()
        if (wasRunning) start()
    }

    fun snapshot(statusOverride: String? = null): Map<String, Any?> {
        val status = statusOverride ?: when {
            lastError.isNotEmpty() -> "error"
            running.get() -> "connected"
            else -> "stopped"
        }
        val uptime = if (running.get()) ((SystemClock.elapsedRealtime() - startElapsed) / 1000L) else 0L
        val network = currentNetworkLabel()
        return mapOf(
            "status" to status,
            "uploadBytesPerSec" to currentUpPerSec,
            "downloadBytesPerSec" to currentDownPerSec,
            "totalUploadBytes" to upBytes.get(),
            "totalDownloadBytes" to downBytes.get(),
            "clientCount" to clients.size,
            "uptimeSeconds" to uptime,
            "latencyMs" to currentLatency,
            "localIp" to localIpv4(),
            "networkType" to network,
            "vpnPrepared" to false,
            "dnsLabel" to dnsLabel(config),
            "httpPort" to config.httpPort,
            "socksPort" to config.socksPort,
            "lastError" to lastError,
        )
    }

    private var currentUpPerSec = 0L
    private var currentDownPerSec = 0L

    private fun sample() {
        if (!running.get()) return
        val up = upBytes.get()
        val down = downBytes.get()
        currentUpPerSec = max(0L, up - lastUp)
        currentDownPerSec = max(0L, down - lastDown)
        lastUp = up
        lastDown = down
        currentLatency = probeLatency()
        emit("connected")
    }

    private fun emit(status: String) = onState(snapshot(status))

    private enum class ProxyKind { HTTP, SOCKS5 }

    private fun acceptLoop(server: ServerSocket, kind: ProxyKind) {
        while (running.get() && !server.isClosed) {
            try {
                val client = server.accept()
                client.tcpNoDelay = config.lowLatencyMode
                client.keepAlive = config.keepAlive
                clients += client
                executor.execute {
                    try {
                        when (kind) {
                            ProxyKind.HTTP -> handleHttp(client)
                            ProxyKind.SOCKS5 -> handleSocks5(client)
                        }
                    } catch (t: Throwable) {
                        if (config.enableLogs) {
                            lastError = humanError(t)
                            logger.log("WARNING", lastError)
                        }
                    } finally {
                        clients.remove(client)
                        runCatching { client.close() }
                        emit(if (running.get()) "connected" else "stopped")
                    }
                }
            } catch (_: SocketException) {
                if (running.get()) sleepQuiet(100)
            } catch (t: Throwable) {
                if (!running.get()) break
                lastError = humanError(t)
                logger.log("WARNING", lastError)
                scheduleReconnectIfNeeded()
                sleepQuiet(150)
            }
        }
    }

    private fun handleHttp(client: Socket) {
        client.soTimeout = config.timeoutMs
        val input = BufferedInputStream(client.getInputStream(), config.bufferSize)
        val output = BufferedOutputStream(client.getOutputStream(), config.bufferSize)
        val headerBytes = readHeaders(input)
        val headerText = String(headerBytes, StandardCharsets.ISO_8859_1)
        val requestLine = headerText.lineSequence().firstOrNull()?.trim().orEmpty()
        val parts = requestLine.split(' ')
        if (parts.size < 2) return
        val method = parts[0].uppercase(Locale.US)
        val rawTarget = parts[1]
        val hostAndPort = if (method == "CONNECT") parseAuthority(rawTarget) else parseHostFromHeaders(headerText, rawTarget)
        if (hostAndPort == null) {
            writeHttpError(output, 400, "Bad Request")
            return
        }
        val (host, port) = hostAndPort
        val upstream = DnsResolver(config).connect(host, port, config.timeoutMs)
        upstream.tcpNoDelay = config.lowLatencyMode
        upstream.keepAlive = config.keepAlive
        upstream.soTimeout = config.timeoutMs

        upstream.getOutputStream().use { upstreamOut ->
            if (method == "CONNECT") {
                output.write("HTTP/1.1 200 Connection Established\r\nProxy-Agent: InterShare\r\n\r\n".toByteArray(StandardCharsets.ISO_8859_1))
                output.flush()
                client.soTimeout = 0
                upstream.soTimeout = 0
                pipeBidirectional(client, upstream, input, output)
            } else {
                val originRequest = rewriteHttpRequest(headerText, rawTarget)
                upstreamOut.write(originRequest.toByteArray(StandardCharsets.ISO_8859_1))
                upstreamOut.flush()
                copyRequestBody(input, upstreamOut, headerText)
                pipeResponse(upstream, client, upstream.getInputStream(), output)
            }
        }
        runCatching { upstream.close() }
    }

    private fun handleSocks5(client: Socket) {
        client.soTimeout = config.timeoutMs
        val input = BufferedInputStream(client.getInputStream(), config.bufferSize)
        val output = BufferedOutputStream(client.getOutputStream(), config.bufferSize)
        val version = input.read()
        if (version != 5) return
        val methodCount = input.read()
        if (methodCount <= 0) return
        val methods = ByteArray(methodCount)
        readFully(input, methods)
        if (!methods.contains(0.toByte())) {
            output.write(byteArrayOf(5, 0xFF.toByte()))
            output.flush()
            return
        }
        output.write(byteArrayOf(5, 0))
        output.flush()

        if (input.read() != 5) return
        val command = input.read()
        input.read() // RSV
        val addressType = input.read()
        val host = when (addressType) {
            1 -> InetAddress.getByAddress(readBytes(input, 4)).hostAddress
            3 -> String(readBytes(input, input.read()), StandardCharsets.UTF_8)
            4 -> InetAddress.getByAddress(readBytes(input, 16)).hostAddress
            else -> null
        } ?: return
        val portBytes = readBytes(input, 2)
        val port = ((portBytes[0].toInt() and 0xff) shl 8) or (portBytes[1].toInt() and 0xff)
        if (command != 1) {
            sendSocksReply(output, 7, 0, 0)
            return
        }
        if (!config.ipv6 && host.contains(':')) {
            sendSocksReply(output, 8, 0, 0)
            return
        }
        val upstream = try {
            DnsResolver(config).connect(host, port, config.timeoutMs)
        } catch (_: Throwable) {
            sendSocksReply(output, 5, 0, 0)
            return
        }
        output.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0))
        output.flush()
        client.soTimeout = 0
        upstream.soTimeout = 0
        pipeBidirectional(client, upstream, input, output)
        runCatching { upstream.close() }
    }

    private fun pipeBidirectional(client: Socket, upstream: Socket, clientIn: InputStream, clientOut: OutputStream) {
        val a = executor.submit { copy(clientIn, upstream.getOutputStream(), true) }
        val b = executor.submit { copy(upstream.getInputStream(), clientOut, false) }
        try {
            b.get()
        } catch (_: Throwable) {
        } finally {
            a.cancel(true)
            runCatching { upstream.shutdownOutput() }
        }
    }

    private fun pipeResponse(upstream: Socket, client: Socket, input: InputStream, output: OutputStream) {
        val buffer = ByteArray(config.bufferSize)
        while (running.get()) {
            val read = try { input.read(buffer) } catch (_: SocketTimeoutException) { break }
            if (read < 0) break
            if (read == 0) continue
            output.write(buffer, 0, read)
            output.flush()
            downBytes.addAndGet(read.toLong())
        }
    }

    private fun copyRequestBody(input: InputStream, upstreamOut: OutputStream, headers: String) {
        val length = headers.lineSequence()
            .firstOrNull { it.startsWith("Content-Length:", ignoreCase = true) }
            ?.substringAfter(':')?.trim()?.toLongOrNull() ?: 0L
        if (length <= 0L || length > 64L * 1024L * 1024L) return
        val buffer = ByteArray(config.bufferSize)
        var remaining = length
        while (remaining > 0) {
            val read = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
            if (read < 0) break
            if (read == 0) continue
            upstreamOut.write(buffer, 0, read)
            upBytes.addAndGet(read.toLong())
            remaining -= read
        }
        upstreamOut.flush()
    }

    private fun copy(input: InputStream, output: OutputStream, upload: Boolean): Long {
        val buffer = ByteArray(config.bufferSize)
        var total = 0L
        while (running.get()) {
            val read = try { input.read(buffer) } catch (_: SocketTimeoutException) { break } catch (_: SocketException) { break }
            if (read < 0) break
            if (read == 0) continue
            output.write(buffer, 0, read)
            output.flush()
            total += read
            if (upload) upBytes.addAndGet(read.toLong()) else downBytes.addAndGet(read.toLong())
        }
        return total
    }

    private fun readHeaders(input: InputStream): ByteArray {
        val out = ByteArrayOutputStream()
        var lastFour = 0
        while (out.size() < 64 * 1024) {
            val b = input.read()
            if (b < 0) throw EOFException("Client closed before headers")
            out.write(b)
            lastFour = ((lastFour shl 8) or (b and 0xff)) and 0xffffffff.toInt()
            if (lastFour == 0x0d0a0d0a) break
        }
        return out.toByteArray()
    }

    private fun parseAuthority(authority: String, defaultPort: Int = 443): Pair<String, Int>? {
        val raw = authority.trim()
        if (raw.startsWith("[")) {
            val end = raw.indexOf(']')
            if (end <= 0) return null
            val host = raw.substring(1, end)
            val port = raw.substring(end + 1).removePrefix(":").toIntOrNull() ?: defaultPort
            return host to port
        }
        val idx = raw.lastIndexOf(':')
        if (idx > 0 && raw.indexOf(':') == idx) {
            return raw.substring(0, idx) to (raw.substring(idx + 1).toIntOrNull() ?: defaultPort)
        }
        return raw to defaultPort
    }

    private fun parseHostFromHeaders(headers: String, target: String): Pair<String, Int>? {
        val uriHost = parseAuthorityFromUrl(target)
        if (uriHost != null) return uriHost
        val hostHeader = headers.lineSequence().firstOrNull { it.startsWith("Host:", ignoreCase = true) }
            ?.substringAfter(':')?.trim()
        return hostHeader?.let { parseAuthority(it, 80) }
    }

    private fun parseAuthorityFromUrl(url: String): Pair<String, Int>? {
        val schemeEnd = url.indexOf("://")
        if (schemeEnd < 0) return null
        val scheme = url.substring(0, schemeEnd).lowercase(Locale.US)
        val authority = url.substring(schemeEnd + 3).substringBefore('/')
        return parseAuthority(authority)?.let { (host, port) -> host to (if (authority.contains(':')) port else if (scheme == "https") 443 else 80) }
    }

    private fun rewriteHttpRequest(headers: String, absoluteTarget: String): String {
        val original = headers.split("\r\n").filter { it.isNotBlank() }.toMutableList()
        if (original.isNotEmpty()) {
            val first = original[0].split(' ')
            if (first.size >= 3) {
                val path = absolutePath(absoluteTarget)
                original[0] = "${first[0]} $path ${first[2]}"
            }
        }
        val kept = original.filterNot { line ->
            val lower = line.lowercase(Locale.US)
            lower.startsWith("proxy-connection:") ||
                lower.startsWith("connection:") ||
                lower.startsWith("proxy-authorization:")
        }.toMutableList()
        kept.add("Connection: close")
        return kept.joinToString("\r\n") + "\r\n\r\n"
    }

    private fun absolutePath(url: String): String {
        val idx = url.indexOf("://")
        if (idx < 0) return url
        val slash = url.indexOf('/', idx + 3)
        return if (slash >= 0) url.substring(slash) else "/"
    }

    private fun writeHttpError(output: OutputStream, code: Int, reason: String) {
        val body = "$code $reason\n".toByteArray(StandardCharsets.UTF_8)
        val header = "HTTP/1.1 $code $reason\r\nContent-Length: ${body.size}\r\nConnection: close\r\nContent-Type: text/plain\r\n\r\n"
        output.write(header.toByteArray(StandardCharsets.ISO_8859_1))
        output.write(body)
        output.flush()
    }

    private fun sendSocksReply(output: OutputStream, rep: Int, port: Int, address: Int) {
        output.write(byteArrayOf(5, rep.toByte(), 0, 1, 0, 0, 0, 0, (port shr 8).toByte(), port.toByte()))
        output.flush()
    }

    private fun readBytes(input: InputStream, length: Int): ByteArray {
        if (length <= 0 || length > 1024) throw EOFException("Invalid proxy length")
        val bytes = ByteArray(length)
        readFully(input, bytes)
        return bytes
    }

    private fun readFully(input: InputStream, buffer: ByteArray) {
        var offset = 0
        while (offset < buffer.size) {
            val read = input.read(buffer, offset, buffer.size - offset)
            if (read < 0) throw EOFException("Unexpected end of stream")
            offset += read
        }
    }

    private fun validateConfig(c: SettingsStore.Config) {
        require(c.httpPort in 1024..65535) { "HTTP port must be between 1024 and 65535" }
        require(c.socksPort in 1024..65535) { "SOCKS5 port must be between 1024 and 65535" }
        require(c.httpPort != c.socksPort || c.proxyMode != "both") { "HTTP and SOCKS5 ports must differ when both are active" }
        require(c.bufferSize in 4096..65536) { "Buffer size is outside the supported range" }
    }

    private fun SettingsStore.Config.sanitized(): SettingsStore.Config {
        val effectiveProfile = profile.lowercase(Locale.US)
        val profileBuffer = when (effectiveProfile) {
            "lowLatency".lowercase(Locale.US) -> 8192
            "performance" -> 32768
            else -> bufferSize
        }.coerceIn(4096, 65536)
        return copy(
            httpPort = httpPort.coerceIn(1024, 65535),
            socksPort = socksPort.coerceIn(1024, 65535),
            timeoutMs = timeoutMs.coerceIn(2000, 20000),
            reconnectDelayMs = reconnectDelayMs.coerceIn(500, 10000),
            bufferSize = profileBuffer,
        )
    }

    private fun scheduleReconnectIfNeeded() {
        if (!config.autoReconnect || !running.get()) return
        val attempt = reconnectAttempt++
        val delay = config.reconnectDelayMs.toLong() * (1L shl minOf(attempt, 6))
        sampler.schedule({
            if (!running.get()) return@schedule
            if (hasNetwork()) {
                logger.log("INFO", "Auto reconnecting local proxy engine")
                runCatching { reload() }
                    .onFailure { logger.log("ERROR", "Reconnect failed: ${it.message}") }
            } else {
                emit("reconnecting")
                scheduleReconnectIfNeeded()
            }
        }, delay.coerceAtMost(60000L), TimeUnit.MILLISECONDS)
    }

    private fun registerNetworkCallback() {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                lastError = "Network lost. Reconnecting..."
                logger.log("WARNING", lastError)
                emit("reconnecting")
                scheduleReconnectIfNeeded()
            }

            override fun onAvailable(network: Network) {
                lastError = ""
                logger.log("INFO", "Network became available")
                reconnectAttempt = 0
                scheduleReconnectIfNeeded()
            }
        }
        networkCallback = callback
        runCatching { cm.registerDefaultNetworkCallback(callback) }
    }

    private fun unregisterNetworkCallback() {
        networkCallback?.let { callback ->
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            runCatching { cm.unregisterNetworkCallback(callback) }
        }
        networkCallback = null
    }


    private fun hasNetwork(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
    private fun currentNetworkLabel(): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "Offline"
        val caps = cm.getNetworkCapabilities(network) ?: return "Offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "Connected"
        }
    }

    private fun localIpv4(): String {
        return runCatching {
            Collections.list(java.net.NetworkInterface.getNetworkInterfaces())
                .flatMap { Collections.list(it.inetAddresses) }
                .filterIsInstance<Inet4Address>()
                .firstOrNull { !it.isLoopbackAddress && it.isSiteLocalAddress }
                ?.hostAddress ?: "—"
        }.getOrDefault("—")
    }

    private fun probeLatency(): Int {
        val start = SystemClock.elapsedRealtime()
        return try {
            Socket().use { socket ->
                socket.connect(java.net.InetSocketAddress("1.1.1.1", 443), config.timeoutMs.coerceAtMost(3000))
            }
            (SystemClock.elapsedRealtime() - start).toInt()
        } catch (_: Throwable) {
            0
        }
    }

    private fun dnsLabel(c: SettingsStore.Config): String = when (c.dnsMode) {
        "cloudflare" -> "Cloudflare (1.1.1.1)"
        "google" -> "Google (8.8.8.8)"
        "custom" -> if (c.customDns.isBlank()) "System Default" else "Custom (${c.customDns})"
        else -> "System Default"
    }

    private fun closeServers() {
        runCatching { httpServer?.close() }
        runCatching { socksServer?.close() }
        httpServer = null
        socksServer = null
    }

    private fun sleepQuiet(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
    }

    private fun humanError(t: Throwable): String = when (t) {
        is java.net.BindException -> "Port is already in use"
        is java.net.UnknownHostException -> "Host could not be resolved"
        is java.net.ConnectException -> "Upstream connection refused or unavailable"
        is SocketTimeoutException -> "Connection timed out"
        else -> t.message?.take(160) ?: t::class.java.simpleName
    }
}
