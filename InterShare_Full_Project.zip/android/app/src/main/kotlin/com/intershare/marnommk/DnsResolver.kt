package com.intershare.marnommk

import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom

class DnsResolver(private val config: SettingsStore.Config) {
    private val random = SecureRandom()

    fun resolve(host: String): List<InetAddress> {
        if (host.isBlank()) return emptyList()
        if (host.matches(Regex("^[0-9.]+$")) || host.contains(':')) {
            runCatching { InetAddress.getByName(host) }.getOrNull()?.let { return listOf(it) }
        }
        val bypassed = config.bypassList.any { pattern ->
            val p = pattern.trim().lowercase()
            val h = host.lowercase()
            h == p || h.endsWith(".$p")
        }
        val server = when (config.dnsMode) {
            "cloudflare" -> "1.1.1.1"
            "google" -> "8.8.8.8"
            "custom" -> config.customDns.trim().ifBlank { null }
            else -> null
        }
        if (server != null && !bypassed) {
            val custom = runCatching { resolveA(host, server) }.getOrDefault(emptyList())
            if (custom.isNotEmpty()) {
                return custom.filter { address -> if (address is java.net.Inet6Address) config.ipv6 else config.ipv4 }
            }
        }
        return runCatching {
            InetAddress.getAllByName(host).toList().filter { address ->
                when (address) {
                    is java.net.Inet4Address -> config.ipv4
                    is java.net.Inet6Address -> config.ipv6
                    else -> true
                }
            }
        }.getOrDefault(emptyList())
    }

    fun connect(host: String, port: Int, timeoutMs: Int): Socket {
        val addresses = resolve(host)
        if (addresses.isEmpty()) throw java.net.UnknownHostException(host)
        var last: Throwable? = null
        for (address in addresses) {
            val socket = Socket()
            try {
                socket.tcpNoDelay = config.lowLatencyMode
                socket.keepAlive = config.keepAlive
                socket.connect(InetSocketAddress(address, port), timeoutMs)
                return socket
            } catch (t: Throwable) {
                last = t
                runCatching { socket.close() }
            }
        }
        throw (last ?: java.net.ConnectException("Unable to connect to $host:$port"))
    }

    private fun resolveA(host: String, server: String): List<InetAddress> {
        val queryId = random.nextInt(0x10000)
        val packet = buildQuery(queryId, host)
        DatagramSocket().use { socket ->
            socket.soTimeout = config.timeoutMs.coerceIn(500, 15000)
            val target = InetSocketAddress(InetAddress.getByName(server), 53)
            socket.send(DatagramPacket(packet, packet.size, target))
            val buffer = ByteArray(2048)
            val response = DatagramPacket(buffer, buffer.size)
            socket.receive(response)
            return parseA(response.data.copyOf(response.length), queryId)
        }
    }

    private fun buildQuery(id: Int, host: String): ByteArray {
        val out = ByteArrayOutputStream()
        fun b(value: Int) = out.write(value and 0xff)
        b(id shr 8); b(id)
        b(0x01); b(0x00)
        b(0x00); b(0x01)
        b(0x00); b(0x00)
        b(0x00); b(0x00)
        b(0x00); b(0x00)
        host.trim('.').split('.').forEach { label ->
            val bytes = label.toByteArray(Charsets.US_ASCII)
            b(bytes.size)
            out.write(bytes)
        }
        b(0)
        b(0); b(1)
        b(0); b(1)
        return out.toByteArray()
    }

    private fun parseA(bytes: ByteArray, expectedId: Int): List<InetAddress> {
        if (bytes.size < 12) return emptyList()
        val id = ((bytes[0].toInt() and 0xff) shl 8) or (bytes[1].toInt() and 0xff)
        if (id != expectedId) return emptyList()
        val answerCount = ((bytes[6].toInt() and 0xff) shl 8) or (bytes[7].toInt() and 0xff)
        var offset = 12
        offset = skipName(bytes, offset)
        if (offset + 4 > bytes.size) return emptyList()
        offset += 4
        val results = ArrayList<InetAddress>()
        repeat(answerCount) {
            if (offset >= bytes.size) return@repeat
            offset = skipName(bytes, offset)
            if (offset + 10 > bytes.size) return@repeat
            val type = u16(bytes, offset); offset += 2
            val clazz = u16(bytes, offset); offset += 2
            offset += 4
            val rdLength = u16(bytes, offset); offset += 2
            if (offset + rdLength > bytes.size) return@repeat
            if (type == 1 && clazz == 1 && rdLength == 4) {
                results += InetAddress.getByAddress(bytes.copyOfRange(offset, offset + 4))
            }
            offset += rdLength
        }
        return results
    }

    private fun u16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xff) shl 8) or (bytes[offset + 1].toInt() and 0xff)

    private fun skipName(bytes: ByteArray, start: Int): Int {
        var offset = start
        var jumps = 0
        while (offset < bytes.size && jumps++ < 64) {
            val length = bytes[offset].toInt() and 0xff
            if (length == 0) return offset + 1
            if ((length and 0xc0) == 0xc0) return offset + 2
            offset += 1 + length
        }
        return bytes.size
    }
}
