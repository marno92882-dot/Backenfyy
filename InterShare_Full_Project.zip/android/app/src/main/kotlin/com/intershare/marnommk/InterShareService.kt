package com.intershare.marnommk

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

class InterShareService : Service() {
    companion object {
        const val ACTION_START = "com.intershare.marnommk.START"
        const val ACTION_STOP = "com.intershare.marnommk.STOP"
        const val ACTION_RELOAD = "com.intershare.marnommk.RELOAD"
        private const val CHANNEL_ID = "intershare_sharing"
        private const val NOTIFICATION_ID = 1811

        @Volatile
        var engine: ProxyEngine? = null
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        if (engine == null) {
            engine = ProxyEngine(applicationContext) { snapshot -> NativeEventBus.emit(snapshot) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                engine?.stop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> runCatching { engine?.reload() }
            else -> {
                try {
                    startAsForeground()
                    if (engine?.isRunning() == true) engine?.reload() else engine?.start()
                } catch (t: Throwable) {
                    NativeEventBus.emit(engine?.snapshot("error") ?: mapOf("status" to "error", "lastError" to (t.message ?: "Unable to start")))
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        engine?.stop()
        engine = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTimeout(startId: Int, fgsType: Int) {
        engine?.stop()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        super.onTimeout(startId, fgsType)
    }

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, InterShareService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.intershare.marnommk.R.drawable.app_icon)
            .setContentTitle("InterShare")
            .setContentText("Sharing active")
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(Notification.Action.Builder(null, "STOP", stopPending).build())
            .build()
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL_ID, "InterShare Sharing", NotificationManager.IMPORTANCE_LOW)
        channel.description = "InterShare foreground sharing service"
        manager.createNotificationChannel(channel)
    }
}
