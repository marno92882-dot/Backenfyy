package com.intershare.marnommk

import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val METHOD_CHANNEL = "com.intershare.marnommk/native"
        private const val EVENT_CHANNEL = "com.intershare.marnommk/events"
        private const val VPN_REQUEST_CODE = 9011
    }

    private lateinit var store: SettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SettingsStore(this)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, METHOD_CHANNEL).setMethodCallHandler { call, result ->
            handleMethod(call, result)
        }
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, EVENT_CHANNEL).setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                NativeEventBus.sink = events
                events?.success(currentSnapshot())
            }

            override fun onCancel(arguments: Any?) {
                NativeEventBus.sink = null
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST_CODE) {
            NativeEventBus.emit(currentSnapshot())
        }
    }

    private fun handleMethod(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "startService" -> {
                    @Suppress("UNCHECKED_CAST")
                    val map = call.arguments as? Map<String, Any?> ?: emptyMap()
                    store.applyMap(map)
                    val intent = Intent(this, InterShareService::class.java).setAction(InterShareService.ACTION_START)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                    result.success(null)
                }
                "stopService" -> {
                    val intent = Intent(this, InterShareService::class.java).setAction(InterShareService.ACTION_STOP)
                    startService(intent)
                    result.success(null)
                }
                "getStats" -> result.success(currentSnapshot())
                "isVpnPrepared" -> result.success(VpnService.prepare(this) == null)
                "prepareVpn" -> {
                    val intent = VpnService.prepare(this)
                    if (intent == null) {
                        result.success(true)
                    } else {
                        startActivityForResult(intent, VPN_REQUEST_CODE)
                        result.success(false)
                    }
                }
                "clearLogs" -> {
                    NativeLogger(this).clear()
                    result.success(null)
                }
                "getLogs" -> result.success(NativeLogger(this).get())
                "exportLogs" -> {
                    val lines = NativeLogger(this).get().joinToString("\n") { "${it["time"]} ${it["level"]} ${it["message"]}" }
                    val share = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "InterShare Logs")
                        putExtra(Intent.EXTRA_TEXT, lines.ifBlank { "No InterShare logs." })
                    }
                    startActivity(Intent.createChooser(share, "Export InterShare Logs"))
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        } catch (t: Throwable) {
            result.error("INTERSHARE_NATIVE", t.message, null)
        }
    }

    private fun currentSnapshot(): Map<String, Any?> {
        val serviceEngine = InterShareService.engine
        return serviceEngine?.snapshot() ?: mapOf(
            "status" to "stopped",
            "uploadBytesPerSec" to 0,
            "downloadBytesPerSec" to 0,
            "totalUploadBytes" to 0,
            "totalDownloadBytes" to 0,
            "clientCount" to 0,
            "uptimeSeconds" to 0,
            "latencyMs" to 0,
            "localIp" to "—",
            "networkType" to "Offline",
            "vpnPrepared" to (VpnService.prepare(this) == null),
            "dnsLabel" to "System Default",
            "httpPort" to store.load().httpPort,
            "socksPort" to store.load().socksPort,
            "lastError" to "",
        )
    }
}
