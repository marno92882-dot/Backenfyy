package com.intershare.marnommk

import io.flutter.plugin.common.EventChannel

object NativeEventBus {
    @Volatile
    var sink: EventChannel.EventSink? = null

    fun emit(payload: Map<String, Any?>) {
        sink?.success(payload)
    }
}
