package com.intershare.marnommk

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED && intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val enabled = SettingsStore(context).load().bootStart
        if (!enabled) return
        val serviceIntent = Intent(context, InterShareService::class.java).setAction(InterShareService.ACTION_START)
        runCatching { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(serviceIntent) else context.startService(serviceIntent) }
    }
}
