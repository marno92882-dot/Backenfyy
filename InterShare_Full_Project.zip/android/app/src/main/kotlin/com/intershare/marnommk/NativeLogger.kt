package com.intershare.marnommk

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NativeLogger(context: Context) {
    private val prefs = context.getSharedPreferences("intershare_logs", Context.MODE_PRIVATE)
    private val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun log(level: String, message: String) {
        val array = readArray()
        val item = JSONObject()
            .put("time", format.format(Date()))
            .put("level", level)
            .put("message", message.take(400))
        array.put(item)
        while (array.length() > 200) array.remove(0)
        prefs.edit().putString("entries", array.toString()).apply()
    }

    @Synchronized
    fun clear() {
        prefs.edit().remove("entries").apply()
    }

    @Synchronized
    fun get(): List<Map<String, String>> {
        val array = readArray()
        val result = ArrayList<Map<String, String>>()
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            result += mapOf(
                "time" to o.optString("time"),
                "level" to o.optString("level"),
                "message" to o.optString("message"),
            )
        }
        return result
    }

    private fun readArray(): JSONArray {
        val raw = prefs.getString("entries", "[]") ?: "[]"
        return runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
    }
}
