package com.intershare.marnommk

import android.content.Intent
import android.net.VpnService

class VpnProbeService : VpnService() {
    private var interfaceHandle: android.os.ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return try {
            interfaceHandle?.close()
            interfaceHandle = Builder()
                .setSession("InterShare")
                .setMtu(1500)
                .addAddress("10.231.0.2", 30)
                .addRoute("10.231.0.0", 30)
                .establish()
            START_NOT_STICKY
        } catch (_: Throwable) {
            stopSelf()
            START_NOT_STICKY
        }
    }

    override fun onDestroy() {
        interfaceHandle?.close()
        interfaceHandle = null
        super.onDestroy()
    }
}
