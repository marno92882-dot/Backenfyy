package com.intershare.marnommk

import android.content.Context

import org.json.JSONArray
import org.json.JSONObject

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("intershare_native", Context.MODE_PRIVATE)

    data class Config(
        val autoReconnect: Boolean = true,
        val keepAlive: Boolean = true,
        val proxyMode: String = "both",
        val httpPort: Int = 8080,
        val socksPort: Int = 1080,
        val dnsMode: String = "system",
        val customDns: String = "",
        val mtu: Int = 1500,
        val timeoutMs: Int = 8000,
        val reconnectDelayMs: Int = 1500,
        val bufferSize: Int = 16384,
        val connectionReuse: Boolean = true,
        val lowLatencyMode: Boolean = false,
        val profile: String = "balanced",
        val enableLogs: Boolean = true,
        val ipv4: Boolean = true,
        val ipv6: Boolean = true,
        val bootStart: Boolean = false,
        val bypassList: List<String> = emptyList(),
    )

    fun applyMap(map: Map<*, *>) {
        val e = prefs.edit()
        fun bool(key: String, default: Boolean) = (map[key] as? Boolean) ?: default
        fun integer(key: String, default: Int) = (map[key] as? Number)?.toInt() ?: default
        fun string(key: String, default: String) = (map[key] as? String) ?: default

        e.putBoolean("autoReconnect", bool("autoReconnect", true))
        e.putBoolean("keepAlive", bool("keepAlive", true))
        e.putString("proxyMode", string("proxyMode", "both"))
        e.putInt("httpPort", integer("httpPort", 8080))
        e.putInt("socksPort", integer("socksPort", 1080))
        e.putString("dnsMode", string("dnsMode", "system"))
        e.putString("customDns", string("customDns", ""))
        e.putInt("mtu", integer("mtu", 1500))
        e.putInt("timeoutMs", integer("connectionTimeoutMs", 8000))
        e.putInt("reconnectDelayMs", integer("reconnectDelayMs", 1500))
        e.putInt("bufferSize", integer("bufferSize", 16384))
        e.putBoolean("connectionReuse", bool("connectionReuse", true))
        e.putBoolean("lowLatencyMode", bool("lowLatencyMode", false))
        e.putString("profile", string("profile", "balanced"))
        e.putBoolean("enableLogs", bool("enableLogs", true))
        e.putBoolean("ipv4", bool("ipv4", true))
        e.putBoolean("ipv6", bool("ipv6", true))
        e.putBoolean("bootStart", bool("bootStart", false))
        val bypass = map["bypassList"] as? List<*> ?: emptyList<Any>()
        e.putStringSet("bypassList", bypass.filterIsInstance<String>().toSet())
        e.apply()
    }

    fun load(): Config = Config(
        autoReconnect = prefs.getBoolean("autoReconnect", true),
        keepAlive = prefs.getBoolean("keepAlive", true),
        proxyMode = prefs.getString("proxyMode", "both") ?: "both",
        httpPort = prefs.getInt("httpPort", 8080),
        socksPort = prefs.getInt("socksPort", 1080),
        dnsMode = prefs.getString("dnsMode", "system") ?: "system",
        customDns = prefs.getString("customDns", "") ?: "",
        mtu = prefs.getInt("mtu", 1500),
        timeoutMs = prefs.getInt("timeoutMs", 8000),
        reconnectDelayMs = prefs.getInt("reconnectDelayMs", 1500),
        bufferSize = prefs.getInt("bufferSize", 16384),
        connectionReuse = prefs.getBoolean("connectionReuse", true),
        lowLatencyMode = prefs.getBoolean("lowLatencyMode", false),
        profile = prefs.getString("profile", "balanced") ?: "balanced",
        enableLogs = prefs.getBoolean("enableLogs", true),
        ipv4 = prefs.getBoolean("ipv4", true),
        ipv6 = prefs.getBoolean("ipv6", true),
        bootStart = prefs.getBoolean("bootStart", false),
        bypassList = prefs.getStringSet("bypassList", emptySet())?.toList() ?: emptyList(),
    )
}
