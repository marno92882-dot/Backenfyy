# Flutter embedding and native service are retained explicitly.
-keep class io.flutter.** { *; }
-keep class com.intershare.marnommk.** { *; }
