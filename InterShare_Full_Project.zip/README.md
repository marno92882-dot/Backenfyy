# InterShare

InterShare is a Flutter + Kotlin Android application focused on **local network sharing through real HTTP and SOCKS5 proxy servers**. It does not require root, private Android APIs, a cloud backend, analytics, or a remote account.

## Toolchain

- Flutter stable: **3.47.0**
- Dart: supplied by Flutter 3.47
- Java: **17**
- Android Gradle Plugin: **9.0.1**
- Gradle: **9.1.0**
- Android compile SDK: **36**
- Android target SDK: **36**
- Minimum SDK: **24**

Flutter 3.47 is the stable release from August 2026. The project uses the modern Flutter Android Gradle plugin layout and Java 17. Flutter 3.47 moved the Android templates toward AGP 9 and built-in Kotlin; this project keeps `android.builtInKotlin=false` because current Flutter ecosystem packages can still apply Kotlin Gradle Plugin in their Android modules. That compatibility choice avoids a known AGP 9 migration failure mode while retaining the modern AGP 9 build layout.

## Important scope / Android limitations

InterShare intentionally exposes **real proxy sharing** rather than simulating a full transparent VPN stack.

### Working modes

- **HTTP Proxy** — real local HTTP forward proxy with HTTPS `CONNECT` support.
- **SOCKS5 Proxy** — real local SOCKS5 `CONNECT` proxy with no-auth negotiation.
- **Both** — both listeners at the same time.

The proxy binds to `0.0.0.0` so devices on the same reachable LAN/hotspot can use the configured proxy port.

### VPN

The Android `VpnService.prepare()` permission flow is implemented so the app can correctly request VPN permission without bypassing system security. The project deliberately does **not** claim to implement transparent whole-device packet forwarding, because doing that reliably requires a complete user-space IP/TCP/UDP forwarding stack. The UI therefore does not expose a fake "VPN mode" that merely toggles a flag.

A small native VPN probe service is included only to validate the official Android `VpnService` integration path when explicitly started by a developer. It does not install a default route and does not intercept the user's internet traffic.

### Foreground service

Sharing is hosted in a visible Android foreground service using the `specialUse` service type. The service declares the corresponding Android 14+ permission and includes a stop action in its notification.

Android 15 places a six-hour timeout on `dataSync` and `mediaProcessing` foreground-service types; those restrictions do not apply to `specialUse`. InterShare uses `specialUse` because its core operation is a user-initiated, ongoing local network proxy service rather than a data-sync job.

Boot auto-start is implemented as an opt-in receiver. Android can still refuse some background service starts depending on device policy or OS state; InterShare catches that failure instead of pretending the service started.

## Network engine

The native Kotlin engine uses:

- `ServerSocket` for local proxy listeners.
- Dedicated worker threads from a cached executor for client connections.
- Buffered asynchronous socket copying.
- `TCP_NODELAY` in low-latency mode.
- Kernel socket keep-alive where configured.
- Bounded exponential reconnect/reload logic.
- ConnectivityManager network callbacks.
- Lightweight 1-second traffic sampling.
- A bounded local native logger.
- Custom DNS for IPv4 A lookups via UDP when Cloudflare, Google, or a custom resolver is selected, with system DNS fallback.
- Bypass rules that skip the configured custom DNS resolver for matching domains and use Android/system resolution.

No fake speed, fake client count, or fake connection state is generated.

## Persistence

Flutter stores user preferences through `SharedPreferencesAsync`. The native service keeps a small mirrored settings store so the background service can restart without relying on a live Flutter UI.

## Build locally

1. Install Flutter 3.47.0 or a newer compatible stable release.
2. Install Android Studio with Android SDK Platform 36 and Build Tools 36.0.0.
3. Install Java 17.
4. Open the project in Android Studio or VS Code.
5. Run:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

The release APK will be under:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## GitHub Actions

`.github/workflows/build.yml` performs:

1. Checkout.
2. Java 17 setup.
3. Flutter 3.47.0 stable setup.
4. `flutter pub get`.
5. `flutter analyze`.
6. `flutter test`.
7. `flutter build apk --release`.
8. APK artifact upload.

## Assets

- `assets/intershare.mp4` — six-second, muted, looping background video generated from the image supplied with this project request, so the ZIP is self-contained even though no separate MP4 was uploaded.
- `assets/profile.jpg` — the supplied image.
- `assets/app_icon_source.jpg` — source copy of the supplied image.
- `android/app/src/main/res/**/ic_launcher_*.png` — generated Android icon densities from the supplied image.

To replace branding, replace `assets/profile.jpg`, `assets/app_icon_source.jpg`, and the Android mipmap PNGs.

## Configuration

### General

- Auto Reconnect
- Auto Start
- Keep Service Alive
- Notification (required while the foreground service is active)

### Network

- Proxy Mode
- HTTP Port
- SOCKS5 Port
- DNS: System Default / Cloudflare / Google / Custom
- Connection timeout
- Reconnect delay

MTU is intentionally not shown as an active Proxy Mode setting because there is no tunnel interface carrying user traffic in Proxy Mode; exposing an MTU slider that changes nothing would be misleading.

### Performance

- Balanced
- Low Latency
- Performance
- Buffer Size
- Connection Reuse / OS keep-alive behavior
- Low Latency Mode / TCP_NODELAY

### Logging

- Enable local logs
- Clear logs
- Export logs using Android's system share sheet

### Advanced

- IPv4
- IPv6
- Domain bypass list
- VPN permission preparation entry

## Using the proxy

After pressing **START SHARING**:

1. Find the phone's local IP in the dashboard.
2. Connect another device to the same reachable Wi-Fi/hotspot/LAN.
3. Set the client HTTP proxy to `<phone-ip>:8080` or SOCKS5 proxy to `<phone-ip>:1080`, unless you changed the ports.
4. HTTPS traffic uses HTTP `CONNECT` or SOCKS5 `CONNECT` to the destination and is not decrypted by InterShare.

The actual internet throughput remains dependent on the phone, upstream Wi-Fi/mobile network, radio conditions, destination server, routing, and the client device. No fixed speed multiplier is promised.

## Error handling

The native layer catches and surfaces:

- Port conflicts.
- DNS resolution failure.
- Upstream connection refusal.
- Socket timeouts.
- Network loss.
- Invalid settings.
- VPN permission denial.
- Foreground-service launch failures.

User-visible errors are concise. Native diagnostic details are kept in the internal local log.

## Troubleshooting

### Port already in use

Change the HTTP or SOCKS5 port in Settings, then start sharing again.

### Client connects but no internet

Confirm the client device is actually using the configured proxy. For HTTPS, the client must support HTTP `CONNECT` when using HTTP Proxy mode. Also check that the upstream phone itself has internet access.

### Android stops the service

Keep the foreground notification enabled, exclude InterShare from aggressive OEM battery optimizers where appropriate, and check Android's per-app battery restrictions. System policies can override an application's wishes.

### VPN permission says not prepared

Open Settings → Advanced → VPN permission. InterShare uses only the official `VpnService.prepare()` flow and will never bypass it.

## Security / privacy

- No backend is required.
- No analytics or trackers are included.
- No API keys or cloud secrets are stored.
- The local proxy has no authentication. Only expose it to networks you trust.
- HTTPS `CONNECT` traffic is forwarded as an encrypted byte stream; InterShare does not decrypt or inspect application payloads.

## Project layout

```text
InterShare_Full_Project/
├── android/
│   └── app/
│       └── src/main/kotlin/com/intershare/marnommk/
├── assets/
├── lib/
│   ├── core/
│   ├── models/
│   ├── native/
│   ├── screens/
│   ├── services/
│   ├── theme/
│   ├── utils/
│   └── widgets/
├── test/
├── .github/workflows/build.yml
├── analysis_options.yaml
├── pubspec.yaml
└── README.md
```
