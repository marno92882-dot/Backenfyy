import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:intershare/widgets/stat_card.dart';

void main() {
  testWidgets('stat card renders label and value', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: StatCard(label: 'Download', value: '1.2 MB/s', icon: Icons.download_rounded),
      ),
    ));
    expect(find.text('Download'), findsOneWidget);
    expect(find.text('1.2 MB/s'), findsOneWidget);
  });
}
