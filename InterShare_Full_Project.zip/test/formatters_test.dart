import 'package:flutter_test/flutter_test.dart';
import 'package:intershare/utils/formatters.dart';

void main() {
  test('formats speeds consistently', () {
    expect(Formatters.speed(512), '512 B/s');
    expect(Formatters.speed(1024), '1.0 KB/s');
    expect(Formatters.speed(1024 * 1024), '1.0 MB/s');
  });

  test('formats uptime', () {
    expect(Formatters.uptime(65), '1m 5s');
    expect(Formatters.uptime(3665), '1h 1m');
  });
}
