import 'package:flutter_test/flutter_test.dart';
import 'package:intershare/models/app_models.dart';
import 'package:intershare/native/native_bridge.dart';

void main() {
  test('maps native connected state', () {
    final stats = NetworkStatsMapper.fromMap({
      'status': 'connected',
      'uploadBytesPerSec': 1000,
      'downloadBytesPerSec': 2000,
      'clientCount': 2,
      'httpPort': 8080,
      'socksPort': 1080,
      'networkType': 'Wi-Fi',
    });
    expect(stats.status, ServiceStatus.connected);
    expect(stats.clientCount, 2);
    expect(stats.httpPort, 8080);
    expect(stats.networkType, 'Wi-Fi');
  });
}
