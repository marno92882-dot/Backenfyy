import 'package:flutter_test/flutter_test.dart';
import 'package:intershare/models/app_models.dart';

void main() {
  test('service states distinguish reconnecting from stopped', () {
    expect(ServiceStatus.reconnecting != ServiceStatus.stopped, isTrue);
    const stats = NetworkStats(status: ServiceStatus.reconnecting, lastError: 'Network lost. Reconnecting...');
    expect(stats.status, ServiceStatus.reconnecting);
    expect(stats.lastError, contains('Reconnecting'));
  });
}
